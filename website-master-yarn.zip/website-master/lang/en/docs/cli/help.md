---
id: docs_cli_help
guide: docs_cli
layout: guide
---

{% include vars.html %}

<p class="lead">Displays help information.</p>

##### `yarn help` <a class="toc" id="toc-yarn-help" href="#toc-yarn-help"></a>

This command shows a list of available commands and flags, each with a brief
explanation on what it does.
