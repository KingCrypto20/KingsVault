---
id: docs_cli_lockfile
guide: docs_cli
layout: guide
---

{% include vars.html %}

The lockfile command isn't necessary. `yarn install` will produce a lockfile.
