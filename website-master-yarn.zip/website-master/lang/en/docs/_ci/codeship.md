Yarn is pre-installed [Codeship Basic](https://codeship.com/features/basic).

If you are using [Codeship Pro](https://pages.codeship.com/docker) (with
Docker), it is recommended to install Yarn
via [our Debian/Ubuntu package](https://yarnpkg.com/en/docs/install#linux-tab)
instead.
