Yarn is pre-installed on [SolanoCI](https://www.solanolabs.com/). You can quickly get up and running by following their
[Yarn documentation](http://docs.solanolabs.com/ConfiguringLanguage/nodejs/#configuration). For an example configuration file,
check out one of [their sample configuration files](https://github.com/solanolabs/express/blob/master/solano.yml).
