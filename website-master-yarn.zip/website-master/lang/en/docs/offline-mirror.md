---
id: docs_offline_mirror
guide: docs_offline_mirror
layout: guide
---

{% include vars.html %}

Follow [this blog post](https://yarnpkg.com/blog/2016/11/24/offline-mirror/) to
configure an offline mirror.
