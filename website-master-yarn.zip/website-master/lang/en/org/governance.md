---
id: governance
guide: yarn_organization
layout: guide
---

This is currently being discussed in
[yarnpkg/yarn#274](https://github.com/yarnpkg/yarn/issues/274).
